// 목록 6.1 기본 함수

'use strict';

exports.handler = function(event, context, callback) {
  callback(null, 'Serverless Architectures on AWS');
};
